import Phaser from 'phaser';
import { InputManager } from './core/input.ts';
import { loadGame, saveGame, hasSave } from './core/save.ts';
import { newGame } from './core/state.ts';
import { Overlay, mountTouchControls } from './ui/overlay.ts';
import { GameAudio } from './game/audio.ts';
import { setCtx, type GameCtx } from './game/ctx.ts';
import { BootScene } from './game/scenes/BootScene.ts';
import { TitleScene } from './game/scenes/TitleScene.ts';
import { FieldScene } from './game/scenes/FieldScene.ts';
import { BattleScene } from './game/scenes/BattleScene.ts';

const input = new InputManager();
const gs = newGame();
const overlay = new Overlay(input, () => ctx.gs.settings);
const audio = new GameAudio(() => ctx.gs.settings);
const ctx: GameCtx = {
  input, overlay, audio, gs,
  hasSave: () => hasSave(),
  persist: () => {
    ctx.gs.savedAt = new Date().toISOString();
    return saveGame(ctx.gs);
  },
  startedAt: Date.now(),
};
setCtx(ctx);
void loadGame;
mountTouchControls(input);

const game = new Phaser.Game({
  type: Phaser.AUTO,
  parent: 'game-canvas',
  width: 320,
  height: 180,
  pixelArt: true,
  backgroundColor: '#000000',
  scale: { mode: Phaser.Scale.NONE },
  scene: [BootScene, TitleScene, FieldScene, BattleScene],
});

game.events.on('step', (time: number) => {
  input.update(time);
  overlay.tick(time);
});
